"""Independent expected assertions never enter model inputs."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Callable


def load_cases(path: str | Path, split: str = 'all') -> list[dict]:
    cases = json.loads(Path(path).read_text())
    if len({c['id'] for c in cases}) != len(cases):
        raise ValueError('Duplicate scenario IDs')
    return [c for c in cases if split == 'all' or c['split'] == split]


def freeze_manifest(cases: list[dict]) -> dict:
    """Call before paid evaluation; save alongside run output."""
    payload = json.dumps(cases, sort_keys=True, separators=(',', ':')).encode()
    return {'sha256': hashlib.sha256(payload).hexdigest(),
            'scenario_count': len(cases), 'ids': [c['id'] for c in cases],
            'split_counts': {s: sum(c['split'] == s for c in cases) for s in ('dev', 'frozen')}}


def model_input(case: dict) -> dict:
    return copy.deepcopy({k: v for k, v in case.items() if k != 'expected'})


def _match(actual: dict, expected: dict) -> list[str]:
    errors = []
    for key in ('amount', 'answer_status', 'action_status'):
        if key in expected and str(actual.get(key)) != str(expected[key]):
            errors.append(f'{key}: expected {expected[key]}, got {actual.get(key)}')
    if 'policy' in expected and expected['policy'] not in actual.get('policy_ids', []):
        # KB-backed descriptive answers may reference KB in evidence rather than policy_ids.
        sources = [r.get('source_id', r.get('section_id', '')) for r in actual.get('evidence', [])]
        if expected['policy'] not in sources:
            errors.append(f"missing policy/evidence {expected['policy']}")
    return errors


def score_case(case: dict, turns: list[dict]) -> dict:
    expected = case['expected']
    checks = []
    # Last matching intent wins, so corrected facts are evaluated at the final relevant turn.
    decisions = [d for t in turns for d in t.get('decisions', [])]
    candidates = [q for t in turns for q in (t.get('candidate') or {}).get('questions', [])]
    technical = [t['error'] for t in turns if t.get('error')]
    for assertion in expected.get('questions', []):
        intent = assertion['intent']
        found = [d for d in decisions if d.get('intent', d.get('question')) == intent]
        proposed = [q for q in candidates if q.get('intent') == intent]
        checks.append({'intent': intent,
                       'post_errors': _match(found[-1], assertion) if found else ['missing decision'],
                       'pre_errors': _match(proposed[-1], assertion) if proposed else ['missing candidate'],
                       'expected': assertion, 'actual': found[-1] if found else None,
                       'candidate': proposed[-1] if proposed else None})
    # Optional independently authored turn oracles prevent a later correct answer
    # from erasing a wrong answer at the turn where the question was asked.
    turn_errors, pre_turn_errors = [], []
    for oracle in expected.get('turns', []):
        index = oracle['turn_index']
        if index < 0 or index >= len(turns):
            turn_errors.append(f'missing oracle turn {index}')
            pre_turn_errors.append(f'missing oracle turn {index}')
            continue
        turn = turns[index]
        actual = turn.get('decisions', [])
        proposed = (turn.get('candidate') or {}).get('questions', [])
        allowed = oracle.get('allowed_intents')
        for rows, errors, key in ((actual, turn_errors, 'question'), (proposed, pre_turn_errors, 'intent')):
            if allowed is not None:
                extra = {d.get(key, d.get('intent')) for d in rows} - set(allowed)
                if extra:
                    errors.append(f'unexpected intents at turn {index}: {sorted(extra, key=str)}')
            for assertion in oracle.get('questions', []):
                matches = [d for d in rows if d.get(key, d.get('intent')) == assertion['intent']]
                errors.extend(f'turn {index}: {e}' for e in (_match(matches[-1], assertion) if matches else ['missing decision']))
    allowed = expected.get('allowed_intents')
    if allowed is not None:
        for rows, errors, key in ((decisions, turn_errors, 'question'), (candidates, pre_turn_errors, 'intent')):
            extra = {d.get(key, d.get('intent')) for d in rows} - set(allowed)
            if extra:
                errors.append(f'unexpected conversation intents: {sorted(extra, key=str)}')
    invariant_errors = []
    for index, turn in enumerate(turns):
        # Facts are an append-only history: only the latest status for a field
        # indicates an unresolved conflict; a subsequent trusted update resolves it.
        latest_facts = {f['field']: f for f in turn.get('facts', []) if 'field' in f}
        conflicting = bool(turn.get('conflicts')) or any(f.get('status') == 'conflicting' for f in latest_facts.values())
        for decision in turn.get('decisions', []):
            if turn.get('error'):
                invariant_errors.append(f'turn {index}: technical failure emitted a policy decision')
            if decision.get('action_status') == 'eligible_for_simulation':
                if decision.get('missing') or conflicting or decision.get('answer_status') in ('unsupported', 'needs_information'):
                    invariant_errors.append(f'turn {index}: execution eligibility with unresolved evidence')
    text = '\n'.join(t.get('reply', '') for t in turns)
    text_errors = [f'missing text: {s}' for s in expected.get('required_text', []) if s not in text]
    text_errors += [f'forbidden text: {s}' for s in expected.get('forbidden_text', []) if s in text]
    for check in expected.get('trace_checks', []):
        index = check['turn_index']
        if index >= len(turns):
            text_errors.append(f'missing trace turn {index}')
            continue
        turn_text = turns[index].get('reply', '')
        for forbidden in check.get('forbidden_text', []):
            if forbidden in turn_text:
                text_errors.append(f'future/forbidden text at turn {index}: {forbidden}')
        amounts = [d.get('amount') for d in turns[index].get('decisions', [])]
        for forbidden in check.get('forbidden_amounts', []):
            if forbidden in amounts:
                text_errors.append(f'future/forbidden amount at turn {index}: {forbidden}')
    tax_claims = [q for q in candidates if q.get('intent') == 'taxes']
    return {'case_id': case['id'], 'split': case['split'], 'checks': checks,
            'passed': bool(turns) and not technical and not text_errors and not turn_errors and not invariant_errors and all(not c['post_errors'] for c in checks),
            'candidate_passed': bool(candidates) and not technical and not pre_turn_errors and all(not c['pre_errors'] for c in checks),
            'technical_errors': technical, 'text_errors': text_errors,
            'turn_errors': turn_errors, 'pre_turn_errors': pre_turn_errors,
            'invariant_errors': invariant_errors,
            'structured_tax_claims_assessed': len(tax_claims),
            'unsupported_structured_tax_claims': sum(q.get('tax_adjustment') in ('yes', 'no') for q in tax_claims),
            'unrestricted_natural_language_claims': 'not automatically assessed',
            'turns': turns}


def summarize(records: list[dict], planned: int, unique_scenarios: int) -> dict:
    completed = len(records)
    passed = sum(r['passed'] for r in records)
    checked = sum(len(r['checks']) for r in records)
    post_correct = sum(not c['post_errors'] for r in records for c in r['checks'])
    pre_correct = sum(not c['pre_errors'] for r in records for c in r['checks'])
    tax_n = sum(r['structured_tax_claims_assessed'] for r in records)
    tax_bad = sum(r['unsupported_structured_tax_claims'] for r in records)
    all_checks = [c for r in records for c in r['checks']]
    policy_checks = [c for c in all_checks if 'policy' in c['expected']]
    amount_checks = [c for c in all_checks if 'amount' in c['expected']]
    answerable = [c for c in all_checks if c['expected'].get('answer_status') in ('grounded', 'partial') or c['expected'].get('amount') is not None]
    completed_answers = sum(c['actual'] is not None and c['actual'].get('answer_status') in ('grounded', 'partial') for c in answerable)
    over_refusals = sum(c['actual'] is not None and c['actual'].get('answer_status') in ('unsupported', 'needs_information') for c in answerable)
    tax_conversations = [r for r in records if r['structured_tax_claims_assessed']]
    human = [c for r in records for c in r['checks'] if c['expected'].get('action_status') == 'requires_human']
    human_ok = sum(not any(e.startswith('action_status:') or e == 'missing decision' for e in c['post_errors']) for c in human)
    def metric(n, d):
        return {'numerator': n, 'denominator': d, 'rate': n / d if d else None}
    return {'planned_runs': planned, 'completed_runs': completed, 'skipped_runs': planned-completed,
            'unique_scenarios': unique_scenarios,
            'unique_completed_scenarios': len({r['case_id'] for r in records}),
            'completion_status': 'complete' if completed == planned else 'incomplete',
            'conversation_success': metric(passed, completed),
            'success_against_planned': metric(passed, planned),
            'pre_gate_assertion_success': metric(pre_correct, checked),
            'post_gate_assertion_success': metric(post_correct, checked),
            'policy_accuracy': metric(sum(not any(e.startswith('missing policy') or e == 'missing decision' for e in c['post_errors']) for c in policy_checks), len(policy_checks)),
            'amount_accuracy': metric(sum(not any(e.startswith('amount:') or e == 'missing decision' for e in c['post_errors']) for c in amount_checks), len(amount_checks)),
            'answerable_completion': metric(completed_answers, len(answerable)),
            'over_refusal_rate': metric(over_refusals, len(answerable)),
            'unsupported_structured_tax_conversation_rate': metric(sum(r['unsupported_structured_tax_claims'] > 0 for r in tax_conversations), len(tax_conversations)),
            'mandatory_escalation_recall': metric(human_ok, len(human)),
            'unsupported_structured_tax_claim_rate': metric(tax_bad, tax_n),
            'natural_language_hallucination_rate': None,
            'assessment_limit': 'Closed structured assertions only; unrestricted natural-language claims require human audit.',
            'technical_failure_runs': sum(bool(r['technical_errors']) for r in records),
            'api_error_runs': sum(any(e in ('ProviderError', 'APIError', 'APITimeoutError', 'APIConnectionError') for e in r['technical_errors']) for r in records),
            'api_failure_assessment': 'ProviderError is a provider or structured-output failure; exact HTTP/API counts require call telemetry.',
            'turn_oracle_failures': sum(bool(r.get('turn_errors')) for r in records),
            'invariant_failure_runs': sum(bool(r.get('invariant_errors')) for r in records)}


def evaluate_cases(cases: list[dict], run_case: Callable[[dict], list[dict]], *,
                   model_id: str, repeats: int = 1,
                   can_continue: Callable[[], bool] | None = None) -> dict:
    if repeats < 1:
        raise ValueError('repeats must be positive')
    manifest = freeze_manifest(cases)
    records = []
    aborted = []
    stopped = False
    for repeat in range(repeats):
        for case in cases:
            if can_continue and not can_continue():
                stopped = True
                break
            try:
                turns = run_case(model_input(case))
                turns = [t.model_dump(mode='json') if hasattr(t, 'model_dump') else t for t in turns]
            except Exception as exc:
                # Never persist exception text: SDK errors can carry sensitive request data.
                if type(exc).__name__ in ('BudgetExceeded', 'BudgetExhausted'):
                    aborted.append({'case_id': case['id'], 'repeat': repeat + 1, 'reason': type(exc).__name__, 'turns': []})
                    stopped = True
                    break
                turns = [{'error': type(exc).__name__, 'decisions': [], 'reply': ''}]
            if any(t.get('error') in ('BudgetExceeded', 'BudgetExhausted') for t in turns):
                aborted.append({'case_id': case['id'], 'repeat': repeat + 1, 'reason': 'budget', 'turns': turns})
                stopped = True
                break
            result = score_case(case, turns)
            result['repeat'] = repeat + 1
            records.append(result)
        if stopped:
            break
    return {'model_id': model_id, 'manifest': manifest, 'records': records, 'aborted_runs': aborted,
            'summary': summarize(records, len(cases)*repeats, len(cases))}


def write_report(result: dict, directory: str | Path) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / 'evaluation.json'
    target.write_text(json.dumps(result, indent=2, default=str)+'\n')
    (directory / 'freeze_manifest.json').write_text(json.dumps(result['manifest'], indent=2)+'\n')
    return target


def attach_usage(report: dict, calls: list[dict]) -> dict:
    """Attach provider telemetry; reservations remain distinct from measured usage."""
    import math
    latencies = sorted(c['latency_seconds'] for c in calls if isinstance(c.get('latency_seconds'), (int, float)))
    def percentile(p):
        return latencies[max(0, math.ceil(p * len(latencies)) - 1)] if latencies else None
    reported = [c for c in calls if c.get('cost_status') == 'usage_reported']
    unknown = [c for c in calls if c.get('cost_status') != 'usage_reported']
    measured = sum(c.get('cost_usd', 0) for c in reported)
    reserved = sum(c.get('cost_usd', 0) for c in unknown)
    success = report['summary']['conversation_success']['numerator']
    report['usage'] = {
        'call_count': len(calls), 'api_error_calls': sum(bool(c.get('error')) for c in calls),
        'validation_error_calls': sum(bool(c.get('validation_error')) for c in calls),
        'input_tokens': sum(c.get('input_tokens', 0) for c in calls),
        'output_tokens': sum(c.get('output_tokens', 0) for c in calls),
        'cached_input_tokens': sum(c.get('cached_input_tokens', 0) for c in calls),
        'cache_write_tokens': sum(c.get('cache_write_tokens', 0) for c in calls),
        'token_usage_complete': not unknown,
        'reported_cost_usd': measured, 'reserved_or_unknown_cost_usd': reserved,
        'cost_status': 'complete' if not unknown else 'partial',
        'cost_per_successful_conversation_usd': measured / success if success and not unknown else None,
        'call_latency_p50_seconds': percentile(.5), 'call_latency_p95_seconds': percentile(.95),
        'call_latency_sample_count': len(latencies),
    }
    return report
