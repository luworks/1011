"""Policy-grounded workflow prototype."""
