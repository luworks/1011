from pathlib import Path
from policy_agent.evaluation import load_cases, model_input, freeze_manifest, evaluate_cases, score_case

FIXTURES = Path(__file__).resolve().parents[1] / 'fixtures/scenarios.json'

def test_case_inventory_and_split():
    cases=load_cases(FIXTURES)
    assert len(cases)>=40
    assert len(load_cases(FIXTURES,'dev'))==24
    assert len(load_cases(FIXTURES,'frozen'))==16
    assert len({c['id'] for c in cases})==len(cases)

def test_expectations_never_enter_runner():
    case=load_cases(FIXTURES)[0]
    def run(payload):
        assert 'expected' not in payload
        payload['trusted_context']['fraud']=True
        return []
    result=evaluate_cases([case],run,model_id='fake')
    assert case['trusted_context']['fraud'] is None
    assert result['summary']['conversation_success']['numerator']==0

def test_budget_denominator_preserved():
    cases=load_cases(FIXTURES,'dev')
    result=evaluate_cases(cases,lambda c:[],model_id='fake',repeats=3,can_continue=lambda:False)
    assert result['summary']['planned_runs']==72
    assert result['summary']['skipped_runs']==72
    assert result['summary']['completion_status']=='incomplete'

def test_manifest_changes_with_ground_truth():
    cases=load_cases(FIXTURES)
    first=freeze_manifest(cases)
    cases[0]['expected']['questions'][0]['amount']='99.00'
    assert first['sha256']!=freeze_manifest(cases)['sha256']

def test_candidate_error_not_hidden_by_gate():
    case=load_cases(FIXTURES)[0]
    case['expected']['questions']=case['expected']['questions'][:1]
    case['expected']['turns']=case['expected']['turns'][:1]
    correct={'question':'outage_credit','policy_ids':['Rule 3'],'amount':'82.50','action_status':'pending_verification'}
    wrong={'intent':'outage_credit','policy_ids':['Rule 2'],'amount':'75.00','action_status':'eligible_for_simulation'}
    result=score_case(case,[{'decisions':[correct],'candidate':{'questions':[wrong]}}])
    assert result['passed']
    assert not result['candidate_passed']

def test_error_text_redacted():
    def run(c):raise RuntimeError('secret-key-do-not-store')
    result=evaluate_cases(load_cases(FIXTURES)[:1],run,model_id='fake')
    assert 'secret-key' not in str(result)
    assert result['summary']['technical_failure_runs']==1
    assert result['summary']['api_error_runs']==0

def test_budget_turn_aborts_without_completed_denominator():
    result=evaluate_cases(load_cases(FIXTURES)[:2],lambda c:[{'error':'BudgetExceeded','reply':''}],model_id='fake')
    assert result['summary']['completed_runs']==0
    assert result['summary']['skipped_runs']==2
    assert len(result['aborted_runs'])==1

def test_separate_accuracy_and_refusal_denominators():
    case={'id':'x','split':'dev','expected':{'questions':[{'intent':'outage_credit','policy':'Rule 3','amount':'82.50'},{'intent':'taxes','answer_status':'partial'}]}}
    result=evaluate_cases([case],lambda c:[{'decisions':[{'question':'outage_credit','policy_ids':['Rule 3'],'amount':'82.50','answer_status':'grounded'},{'question':'taxes','answer_status':'unsupported'}]}],model_id='fake')
    s=result['summary']
    assert s['policy_accuracy']['rate']==1
    assert s['amount_accuracy']['denominator']==1
    assert s['answerable_completion']['denominator']==2
    assert s['over_refusal_rate']['rate']==.5

def test_unknown_usage_not_zero_cost():
    from policy_agent.evaluation import attach_usage
    report={'summary':{'conversation_success':{'numerator':1}}}
    attach_usage(report,[{'cost_status':'usage_reported','cost_usd':.1,'input_tokens':2,'output_tokens':3,'latency_seconds':1},{'cost_status':'reserved_or_unknown','cost_usd':.2,'error':'Timeout','latency_seconds':2}])
    assert report['usage']['reported_cost_usd']==.1
    assert report['usage']['cost_per_successful_conversation_usd'] is None
    assert report['usage']['call_latency_p95_seconds']==2
    assert report['usage']['api_error_calls']==1

def test_intermediate_future_information_rejected():
    case={'id':'x','split':'dev','expected':{'questions':[], 'trace_checks':[{'turn_index':0,'forbidden_amounts':['82.50']}]}}
    result=score_case(case,[{'decisions':[{'amount':'82.50'}],'reply':'credit'}])
    assert not result['passed']
    assert 'future/forbidden amount' in result['text_errors'][0]


def test_turn_oracle_rejects_early_wrong_answer_and_extra_intents():
    case={'id':'x','split':'dev','expected':{'questions':[{'intent':'outage_credit','amount':'82.50'}],
        'turns':[{'turn_index':0,'allowed_intents':['outage_credit'],
                  'questions':[{'intent':'outage_credit','amount':'82.50'}]}]}}
    wrong={'question':'outage_credit','amount':'999.00'}
    correct={'question':'outage_credit','amount':'82.50'}
    result=score_case(case,[{'decisions':[wrong,{'question':'taxes'}],
        'candidate':{'questions':[{'intent':'outage_credit','amount':'82.50'},{'intent':'taxes'}]}},
        {'decisions':[correct]}])
    assert not result['passed']
    assert not result['candidate_passed']
    assert any('amount:' in e for e in result['turn_errors'])
    assert any('unexpected intents' in e for e in result['turn_errors'])
    assert result['pre_turn_errors']


def test_missing_turn_oracle_cannot_pass():
    case={'id':'x','split':'dev','expected':{'questions':[],
        'turns':[{'turn_index':1,'allowed_intents':[]}]}}
    assert not score_case(case,[{'decisions':[]}])['passed']


def test_every_turn_checks_execution_evidence_even_if_later_correct():
    case={'id':'x','split':'dev','expected':{'questions':[]}}
    for patch in ({'missing':['history']},{'answer_status':'unsupported'},{}):
        bad={'action_status':'eligible_for_simulation',**patch}
        facts=[{'field':'monthly_charge','status':'conflicting'}] if not patch else []
        result=score_case(case,[{'decisions':[bad],'facts':facts},{'decisions':[]}])
        assert not result['passed']
        assert result['invariant_errors']


def test_resolved_historical_conflict_does_not_fail_invariant():
    case={'id':'x','split':'dev','expected':{'questions':[]}}
    result=score_case(case,[{'decisions':[{'action_status':'eligible_for_simulation','answer_status':'grounded'}],
        'facts':[{'field':'monthly_charge','status':'conflicting'}, {'field':'monthly_charge','status':'confirmed'}]}])
    assert result['passed']


def test_correct_missing_information_is_not_over_refusal():
    case={'id':'x','split':'dev','expected':{'questions':[{'intent':'outage_credit','amount':None,'answer_status':'needs_information'}]}}
    result=evaluate_cases([case],lambda c:[{'decisions':[{'question':'outage_credit','amount':None,'answer_status':'needs_information'}]}],model_id='fake')
    assert result['records'][0]['passed']
    assert result['summary']['over_refusal_rate']['denominator']==0


def test_technical_failure_cannot_emit_successful_policy_decision():
    case={'id':'x','split':'dev','expected':{'questions':[]}}
    result=score_case(case,[{'error':'ProviderError','decisions':[{'question':'taxes'}]}])
    assert not result['passed']
    assert result['invariant_errors']


def test_dev_turn_oracles_cover_each_customer_message():
    for case in load_cases(FIXTURES,'dev'):
        customer_count=sum(isinstance(m,str) or m.get('role') in ('user','customer') for m in case['messages'])
        assert [t['turn_index'] for t in case['expected']['turns']]==list(range(customer_count))
        for oracle in case['expected']['turns']:
            assert {q['intent'] for q in oracle['questions']} <= set(oracle['allowed_intents'])


def test_history_oracle_checks_pending_before_verified():
    case=next(c for c in load_cases(FIXTURES,'dev') if c['id']=='unchecked_history')
    assert case['expected']['turns'][0]['questions'][0]['action_status']=='pending_verification'
    assert case['expected']['turns'][1]['questions'][0]['action_status']=='eligible_for_simulation'
