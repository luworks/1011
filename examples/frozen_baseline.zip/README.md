# Policy-Grounded Agent Prototype

A runnable CLI for Nimbus Wireless billing questions. It separates language-model understanding from a reviewed, deterministic policy decision gate. It exposes the retrieved source text, governing policies, candidate decisions, final decisions, and missing verification for each customer turn.

## Quick start

Requires Python 3.12+ and [uv](https://docs.astral.sh/uv/). Run from the extracted project directory:

```sh
uv sync --frozen
./run.sh doctor
./run.sh replay --offline
uv run pytest -q
```

`run.sh` changes to the project root and invokes `uv run --frozen prototype`. The offline replay uses explicit fixtures for the supplied transcript; it is not an LLM evaluation or a general offline chatbot.

For real model calls, create a local `.env` using `.env.example`, set `OPENAI_API_KEY` and/or `ANTHROPIC_API_KEY`, and choose a model ID from `config/models.json`:

```sh
./run.sh doctor --check-api --provider openai --model gpt-5.4-mini
./run.sh replay --provider openai --model gpt-5.4-mini
./run.sh chat --provider openai --model gpt-5.4-mini
./run.sh evaluate --matrix config/models.json --suite dev --max-cost-usd 5
./run.sh report --run-dir runs/REPLACE_WITH_RUN_DIRECTORY
```

The configured Anthropic candidates use `--provider anthropic`. Access is account-dependent; a configured model is not evidence that credentials or access work. No provider/model fallback is performed silently. Live commands spend API credits. All live commands share the default `runs/budget.json` ledger and a cumulative US$5 cap, including probes and replays. `--ledger` selects a different ledger only for a deliberately separate experiment; `--max-cost-usd` changes its cap. Evaluation reserves estimated costs before requests, includes retries, and stops when its budget cannot fund another request. Estimates are not provider invoices. Do not publish `.env` or unreviewed run logs.

## What a reviewer should see

The supplied conversation is processed chronologically. Previous customer statements and historical agent confirmations are available only after they appear. Historical agent confirmation is labeled as supplied transcript evidence, not a newly performed backend check.

Terminal output displays governing IDs, source paths and line references, missing checks, gate corrections, and the reply. The saved `turns.jsonl` contains full retrieved excerpts and the structured raw/final decisions. Use the JSON trace when inspecting citation content rather than just the terminal summary.

For the outage in the supplied conversation, Rule 3 yields `$225 / 30 × 11 = $82.50`. The monthly amount already covers three lines. The general Rule 2 `$75` ceiling does not apply, but Rules 4 and 5 still govern escalation and authority. Missing fraud/dispute-history checks prevent an automatic credit even when an amount can be calculated. The 30-calendar-day outage-request window is distinct from the 60-day statement-dispute window.

KB-1004 supports the credit calculation base. It does **not** establish whether taxes or regulatory fees are adjusted afterward. The final response states this coverage gap and requests human clarification instead of asserting either a refund or no refund.

## Architecture and boundaries

1. The official OpenAI Responses or Anthropic Messages SDK extracts intents and source-quoted candidate facts.
2. Source checks preserve reported, confirmed, unknown, and conflicting facts. Customer assertions cannot establish backend verification.
3. Local text retrieval adds explicit related-policy dependencies. Unsupported topics search the complete small corpus. All ten articles, KB-1001 through KB-1010, are loaded despite the excerpt's nine-article heading.
4. The model proposes structured decisions with citations. The program independently applies reviewed policy rules and computes Decimal amounts.
5. Bounded, reviewed response templates render approved conclusions. Unrestricted model prose never becomes a policy promise. Model citation/mismatch errors remain visible in the trace.

This is a closed-policy prototype, not a general policy compiler. A corpus hash lock requires review after policy changes. Exact quote validation does not prove that an extracted value means what the model claims; semantic extraction and intent omissions remain residual risks. The gate cannot repair every upstream misunderstanding, so raw model and final workflow quality must both be measured.

Account lookups are local fixtures. No production billing, payment, or human-support integration exists. Eligibility, a need for human review, and an executed action are different states. This prototype does not issue money or claim an external handoff succeeded.

Replay uses the supplied conversation's request date. Interactive `chat --date 2026-10-05` sets an explicit request date; without this flag chat uses the execution host's local date. `chat --context path/to/account.json` loads explicitly simulated account state; it does not inherit transcript verification. Elapsed full days drive the supplied formula; Decimal results are rounded to cents using half-up rounding. These arithmetic conventions are implementation assumptions where the source lacks finer specification. Missing or contradictory facts must be resolved before a definitive eligibility/action decision.

## Results and evaluation

Run directories contain machine-readable turn traces and manifests/report data, including model configuration, source/prompt versions, usage, errors, and costs. Terminal output provides a readable view. These structures are intended to support a later frontend without duplicating policy logic.

The scenario suite contains 24 development and 16 frozen cases with independent expected outcomes. Cases cover amount/time boundaries, unknown verification, policy exceptions, unsupported tax claims, injection attempts, conflicts, and multi-turn ordering. Deterministic tests also exercise technical failures. Expectations are not sent to the model. Offline runs are labeled and excluded from live model comparisons.

Use development cases to change prompts. Run frozen cases only after candidate settings are fixed; repeat frozen evaluation three times per model. For example:

```sh
./run.sh evaluate --suite dev --limit 4 --only-model gpt-5.4-mini --output runs/pilot
./run.sh evaluate --suite frozen --repeats 3 --max-cost-usd 5 --output runs/frozen
```

`--only-model` may be repeated; it filters model IDs in the matrix (evaluation does not select models through `--provider`). `--limit` explicitly selects a subset, so do not describe that result as the full suite. `--output` must name a new directory. `report --run-dir` prints that directory’s stored summary; it does not rerun models.

 If frozen failures guide changes, treat those cases as regression data and replace the holdout. Report the actual run denominator, technical failures, skipped cases, and remaining cases rather than calling a budget-truncated run complete.

Compare raw candidate correctness with final policy/amount correctness, required escalation recall, supported-question completion, unsupported claims, conversation success, latency, and cost per successful conversation. Semantic disagreements require review. Zero failures in a small suite is not a zero-hallucination guarantee. Current measured results and limitations are summarized in the accompanying design memo.

## Curating evaluation artifacts

Export only explicitly selected runs after reviewing their scope. This does not rerun models or reinterpret failures:

```sh
uv run python scripts/export_results.py runs/SELECTED_DEV_RUN runs/SELECTED_FROZEN_RUN --replay runs/SELECTED_REPLAY
```

The exporter writes `examples/summary.json` with metrics, manifests, call telemetry and per-case pre/post errors, removing repeated full turn payloads; `comparison.md` summarizes per-run denominators and costs. Optional `original-conversation.jsonl` preserves the selected replay's full evidence. `examples/manifest.json` records source-file SHA256 hashes and export scope. No benchmark scores are merged across different experiments, and selected runs may be explicitly incomplete. Secret checks run before writing. These files are the only selected result snapshots included in the submission.

## Submission packaging

```sh
uv run python scripts/package.py
```

Creates `dist/policy-grounded-agent-prototype.zip` containing `agent_prototype.zip` and the one-page `design_memo.md`. The inner archive has this README at its root. Packaging uses a narrow allowlist, excludes `.env`, virtual environments and arbitrary run directories. Curated artifacts under `examples/` are included with their own manifest; these are reviewed snapshots, not all local runs. Packaging rejects matching local credential values or recognizable API secrets. It does not replace reviewing artifacts before distribution. Package creation is separate from test or live-evaluation success.
